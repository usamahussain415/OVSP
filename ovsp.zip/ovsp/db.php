<?php

$user="localhost";
$name="root";
$pass="";
$dname="ovsp";
 $con=mysqli_connect($user,$name,$pass,$dname);

?>