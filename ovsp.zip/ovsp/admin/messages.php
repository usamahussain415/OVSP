<?php
	
if (isset($_GET['msg']) && !empty($_GET['msg'])) {
	
	echo $_GET['msg'];

} elseif (isset($_GET['id_num']) && !empty($_GET['id_num']) && isset($_GET['time']) && !empty($_GET['time'])) {
	
	include 'include/global.php';
	include 'include/function.php';
	
	$id_num	= $_GET['id_num'];
	$time		= date('Y-m-d H:i:s', strtotime($_GET['time']));
	
	echo $id_num." login success on ".date('Y-m-d H:i:s', strtotime($time));
	
} else {
		
	$msg = "Parameter invalid..";
	
	echo "$msg";
	
}

	
?>