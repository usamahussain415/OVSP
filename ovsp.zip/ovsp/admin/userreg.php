<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<title>OVSP Admin Panel</title>
<link href="css/style.min.css" rel="stylesheet">
</head>
<body>
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
<div class="lds-ripple">
<div class="lds-pos"></div>
<div class="lds-pos"></div>
</div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
<!-- ============================================================== -->
<!-- Topbar header - style you can find in pages.scss -->
<!-- ============================================================== -->
<header class="topbar" data-navbarbg="skin5">
<nav class="navbar top-navbar navbar-expand-md navbar-dark">
<div class="navbar-header" data-logobg="skin6">
<!-- ============================================================== -->
<!-- Logo -->
<!-- ============================================================== -->
<a class="navbar-brand" href="adminpanel.php">
<!-- Logo icon -->
<b class="logo-icon">
<!-- Dark Logo icon -->
<img src="logo.png" style="height:50px;width: 200px;">

</b>
<!--End Logo icon -->
<!-- Logo text -->

</a>
<!-- ============================================================== -->
<!-- End Logo -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- toggle and nav items -->
<!-- ============================================================== -->
<a class="nav-toggler waves-effect waves-light text-dark d-block d-md-none"
href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
</div>
<!-- ============================================================== -->
<!-- End Logo -->
<!-- ============================================================== -->
<div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
<ul class="navbar-nav d-none d-md-block d-lg-none">
<li class="nav-item">
<a class="nav-toggler nav-link waves-effect waves-light text-white"
href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
</li>
</ul>
<!-- ============================================================== -->
<!-- Right side toggle and nav items -->
<!-- ============================================================== -->
</div>
<div class="d-flex " style="margin-right:2%;">
<a href="logout.php"><button class="btn btn-danger" type="submit">Logout</button></a>
</div>
</nav>
</header>
<!-- ============================================================== -->
<!-- End Topbar header -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar" data-sidebarbg="skin6">
<!-- Sidebar scroll-->
<div class="scroll-sidebar">
<!-- Sidebar navigation-->
<nav class="sidebar-nav">
<ul id="sidebarnav">
<!-- User Profile-->
<li class="sidebar-item pt-2">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="adminreg.php"
aria-expanded="false">
<i class="far fa-clock" aria-hidden="true"></i>
<span class="hide-menu">Admin Registration</span>
</a>
</li>
<li class="sidebar-item pt-2">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="userreg.php"
aria-expanded="false">
<i class="far fa-clock" aria-hidden="true"></i>
<span class="hide-menu">User Registration</span>
</a>
</li>
<li class="sidebar-item pt-2">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="addfinger.php"
aria-expanded="false">
<i class="fas fa-fingerprint"></i>
<span class="hide-menu">Add Finger Print</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="nationalcard.php"
aria-expanded="false">
<i class="fa fa-table" aria-hidden="true"></i>
<span class="hide-menu">National Card</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="proviencecard.php"
aria-expanded="false">
<i class="fa fa-font" aria-hidden="true"></i>
<span class="hide-menu">Provience Card</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="shownationalcard.php"
aria-expanded="false">
<i class="fa fa-globe" aria-hidden="true"></i>
<span class="hide-menu">Show National Cards</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="showproviencecard.php"
aria-expanded="false">
<i class="fa fa-columns" aria-hidden="true"></i>
<span class="hide-menu">Show Province Card</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="result.php"
aria-expanded="false">
<i class="fa fa-info-circle" aria-hidden="true"></i>
<span class="hide-menu">Result</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="feedback.php"
aria-expanded="false">
<i class="fa fa-info-circle" aria-hidden="true"></i>
<span class="hide-menu">Feedback</span>
</a>
</li>

</ul>

</nav>
<!-- End Sidebar navigation -->
</div>
<!-- End Sidebar scroll-->
</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Page wrapper  -->
<!-- ============================================================== -->

<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->

<!--Section: Contact v.2-->
<section class="mb-4">
<div class="container">
<div class="row justify-content-md-center">
<div class="row">
<!--Start Column 8-->
</div>
<div class="col-8">
<div class="row">


<div class="col-md-10 mb-md-0 mb-5" style="margin-top:5%; margin-left:20%">
<form  action="" method="POST" enctype="multipart/form-data">

<div class="row">
<div class="col-md-12">
<div class="md-form mb-0">
<label for="subject" class="">Id Card Number</label>
<input type="text" id="subject" name="idnum" class="form-control" pattern="[0-9]{13}" Placeholder="Enter 13 Digits only" required>
</div>
</div>
</div>    


<div class="row" >

<div class="col-md-6">
<div class="md-form mb-0">
<label for="name" class="">First Name </label>
<input type="text" id="title" name="fname" class="form-control" required>

</div>
</div>

<div class="col-md-6">
<div class="md-form mb-0">
<label for="email" class="">Last Name</label>
<input type="text" id="category" name="lname" class="form-control" required>

</div>

</div>


<div class="col-md-6">
<div class="md-form mb-0">
<label for="email" class="">Father Name</label>
<input type="text" id="category" name="fathername" class="form-control" required>

</div>

</div>

<div class="col-md-6">
<div class="md-form mb-0">
<label for="email" class="">Area Number</label>
<input type="text" id="category" name="areanum" class="form-control" required>

</div>

</div>
<div class="col-md-6">
<div class="md-form mb-0">
<label for="email" class="">Date of Birth</label>
<input type="date" id="category" name="dob" class="form-control" required>

</div>
</div>
<input type="hidden" name="id">

<div class="col-md-6">
<div class="md-form mb-0">
<label for="email" class="">Issue Date</label>
<input type="date" id="category" name="issuedate" class="form-control" required>

</div>
</div>

<div class="row">
<div class="col-md-12">
<div class="md-form mb-0">
<label for="subject" class="">Image</label>
<input type="file" id="subject" name="img" class="form-control">
</div>
</div>
</div>    

<div class="row">

<!--Grid column-->
<div class="col-md-12">

<div class="md-form">
<label for="message">Address</label>
<textarea type="text" id="message" name="address" rows="2" class="form-control md-textarea" required></textarea>

</div>

</div>
</div>
</div>







<br>
<!--Grid row-->
<div class="text-center text-md-left">
<input class="btn btn-primary" type="submit" name="submit">
</div>
</form>
</div>


</div>
</section>
<!--Section: Contact v.2-->
<script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/app-style-switcher.js"></script>
<!--Wave Effects -->
<script src="js/waves.js"></script>
<!--Menu sidebar -->
<script src="js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="js/custom.js"></script>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>



<?php
$user="localhost";
$name="root";
$pass="";
$dname="ovsp";
$con=mysqli_connect($user,$name,$pass,$dname);
if(isset($_POST['submit'])){
$id=mysqli_real_escape_string($con,$_POST['id']);
$idnum=mysqli_real_escape_string($con,$_POST['idnum']);
$fname=mysqli_real_escape_string($con,$_POST['fname']);
$lname=mysqli_real_escape_string($con,$_POST['lname']);
$fathername=mysqli_real_escape_string($con,$_POST['fathername']);
$areanum=mysqli_real_escape_string($con,$_POST['areanum']);
$dob=mysqli_real_escape_string($con,$_POST['dob']);
$issuedate=mysqli_real_escape_string($con,$_POST['issuedate']);
$address=mysqli_real_escape_string($con,$_POST['address']);
$img=$_FILES['img'];

$imgname=$img['name'];
$imgpath=$img['tmp_name'];
$imgerror=$img['error'];

$imgdest='upload/'.$imgname;
move_uploaded_file($imgpath,$imgdest);

$idquery="select * from userreg where id_num='$idnum' ";
$queryfire = mysqli_query($con, $idquery);
$num = mysqli_num_rows($queryfire);
if($num>0){
?>
<script>
alert("This IdCard is already taken!!")
</script>
<?php
}
else{
?>

<script>
alert ("Data Successfully Submitted!!");
</script>
<?php
$dat="insert into userreg( `id_num`, `first_name`, `last_name`, `father_name`, `areanum`, `date_of_birth`, `issue_date`, `img`,`address`)values('$idnum','$fname','$lname','$fathername','$areanum','$dob','$issuedate','$imgdest','$address')";
$query=mysqli_query($con,$dat);
}
}
?>
