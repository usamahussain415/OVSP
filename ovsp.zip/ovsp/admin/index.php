<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<div class="box">
  <h2>Admin Panel</h2>
  <form  method="POST" enctype="multipart/form-data">
    <div class="inputBox">
      <input type="number" name="idnum" required >
      <label>Id Card Number</label>
    </div>
    <div class="inputBox">
      <input type="password" name="password" required>
      <label>Password</label>
    </div>
    <input type="submit" name="submit" value="Sign In">
  </form>
</div>
</body>
</html>

<?php
$user="localhost";
$name="root";
$pass="";
$dname="ovsp";
 $con=mysqli_connect($user,$name,$pass,$dname);
if (isset($_POST['submit'])) {
  $idnum=$_POST['idnum'];
  $password=$_POST['password'];

  $password=md5($password);
  $query = "SELECT * FROM adminreg WHERE id_num='$idnum' AND password='$password'";
  	$results = mysqli_query($con, $query);
  	if (mysqli_num_rows($results) == 1) {
      print "LogIn Succesfully";
  	  header('location: adminpanel.php');
  	}else {
      ?>
      <script>alert("Id Card Number is Incorrect/Passwor is Incorrect");</script>
      <?php
  	}
}


?>