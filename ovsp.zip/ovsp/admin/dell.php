
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $user="localhost";
    $name="root";
    $pass="";
    $tname="ovsp";
    $conn=mysqli_connect($user,$name,$pass,$tname);
    /*if(isset($_GET['dellbtn'])){
        $dell=$_GET['id'];
        $dellquery="delete from data where id=$dell";
        $dellconn=mysqli_query($con,$dellquery);
    }*/
$id = $_GET['id']; // get id through query string

$del = mysqli_query($conn,"delete from proviencecard where id = '$id'"); // delete query

if($del)
{
    mysqli_close($conn); // Close connection
    ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
            })
            .then((willDelete) => {
            if (willDelete) {
                swal("Poof! Your imaginary file has been deleted!", {
                icon: "success",
                });
            window.location="showproviencecard.php";

            } else {
                swal("Your imaginary file is safe!");
            }
            window.location="showproviencecard.php";

            });

    </script>
    <?php
    	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
    ?>
</body>
</html>