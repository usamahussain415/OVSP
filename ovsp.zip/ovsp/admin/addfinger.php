<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Tell the browser to be responsive to screen width -->
<title>OVSP Admin Panel</title>
		<?php include 'include/head.php'; ?>
<link href="css/style.min.css" rel="stylesheet">
</head>
<body>
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
<div class="lds-ripple">
<div class="lds-pos"></div>
<div class="lds-pos"></div>
</div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
<!-- ============================================================== -->
<!-- Topbar header - style you can find in pages.scss -->
<!-- ============================================================== -->
<header class="topbar" data-navbarbg="skin5">
<nav class="navbar top-navbar navbar-expand-md navbar-dark">
<div class="navbar-header" data-logobg="skin6">
<!-- ============================================================== -->
<!-- Logo -->
<!-- ============================================================== -->
<a class="navbar-brand" href="adminpanel.php">
<!-- Logo icon -->
<b class="logo-icon">
<!-- Dark Logo icon -->
<img src="logo.png" style="height:50px;width: 200px;">

</b>
<!--End Logo icon -->
<!-- Logo text -->

</a>
<!-- ============================================================== -->
<!-- End Logo -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- toggle and nav items -->
<!-- ============================================================== -->
<a class="nav-toggler waves-effect waves-light text-dark d-block d-md-none"
href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
</div>
<!-- ============================================================== -->
<!-- End Logo -->
<!-- ============================================================== -->
<div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
<ul class="navbar-nav d-none d-md-block d-lg-none">
<li class="nav-item">
<a class="nav-toggler nav-link waves-effect waves-light text-white"
href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
</li>
</ul>
<!-- ============================================================== -->
<!-- Right side toggle and nav items -->
<!-- ============================================================== -->
</div>
<div class="d-flex " style="margin-right:2%;">
<a href="logout.php"><button class="btn btn-danger" type="submit">Logout</button></a>
</div>
</nav>
</header>
<!-- ============================================================== -->
<!-- End Topbar header -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar" data-sidebarbg="skin6">
<!-- Sidebar scroll-->
<div class="scroll-sidebar">
<!-- Sidebar navigation-->
<nav class="sidebar-nav">
<ul id="sidebarnav">
<!-- User Profile-->
<li class="sidebar-item pt-2">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="adminreg.php"
aria-expanded="false">
<i class="far fa-clock" aria-hidden="true"></i>
<span class="hide-menu">Admin Registration</span>
</a>
</li>
<li class="sidebar-item pt-2">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="userreg.php"
aria-expanded="false">
<i class="far fa-clock" aria-hidden="true"></i>
<span class="hide-menu">User Registration</span>
</a>
</li>
<li class="sidebar-item pt-2">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="addfinger.php"
aria-expanded="false">
<i class="fas fa-fingerprint"></i>
<span class="hide-menu">Add Finger Print</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="nationalcard.php"
aria-expanded="false">
<i class="fa fa-table" aria-hidden="true"></i>
<span class="hide-menu">National Card</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="proviencecard.php"
aria-expanded="false">
<i class="fa fa-font" aria-hidden="true"></i>
<span class="hide-menu">Provience Card</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="shownationalcard.php"
aria-expanded="false">
<i class="fa fa-globe" aria-hidden="true"></i>
<span class="hide-menu">Show National Cards</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="showproviencecard.php"
aria-expanded="false">
<i class="fa fa-columns" aria-hidden="true"></i>
<span class="hide-menu">Show Province Card</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="result.php"
aria-expanded="false">
<i class="fa fa-info-circle" aria-hidden="true"></i>
<span class="hide-menu">Result</span>
</a>
</li>
<li class="sidebar-item">
<a class="sidebar-link waves-effect waves-dark sidebar-link" href="feedback.php"
aria-expanded="false">
<i class="fa fa-info-circle" aria-hidden="true"></i>
<span class="hide-menu">Feedback</span>
</a>
</li>

</ul>

</nav>
<!-- End Sidebar navigation -->
</div>
<!-- End Sidebar scroll-->
</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Page wrapper  -->
<!-- ============================================================== -->

<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->

<!--Section: Contact v.2-->
<section class="mb-4">
<div class="container">
<div class="row justify-content-md-center">
<div class="row">
<!--Start Column 8-->
</div>
<div class="col-8 mt-5" style="margin-left:10em">
<?php
if (isset($_GET['action']) && $_GET['action'] == 'index') {
 ?>
<script type="text/javascript">
function user_register(user_id, id_num) {

$('body').ajaxMask();

regStats = 0;
regCt = -1;
try
{
timer_register.stop();
}
catch(err)	
{
console.log('Registration timer has been init');
}


var limit = 4;
var ct = 1;
var timeout = 5000;

timer_register = $.timer(timeout, function() {					
console.log("'"+id_num+"' registration checking...");
user_checkregister(user_id,$("#user_finger_"+user_id).html());
if (ct>=limit || regStats==1) 
{
timer_register.stop();
console.log("'"+id_num+"' registration checking end");
if (ct>=limit && regStats == 0)
{
alert("'"+id_num+"' registration fail!");
$('body').ajaxMask({ stop: true });
load('addfinger.php');
}						
if (regStats == 1)
{
$("#user_finger_"+user_id).html(regCt);
alert("'"+id_num+"' registration success!");
$('body').ajaxMask({ stop: true });
load('addfinger.php');
}
}
ct++;
});
}

function user_checkregister(user_id, current) {
$.ajax({
url			:	"addfinger.php?action=checkreg&user_id="+user_id+"&current="+current,
type		:	"GET",
success		:	function(data)
{
try
{
var res = jQuery.parseJSON(data);	
if (res.result)
{
regStats = 1;
$.each(res, function(key, value){
if (key=='current')
{														
regCt = value;
}
});
}
}
catch(err)
{
alert(err.message);
}
}
});
}

</script>

<?php
}
include 'include/global.php';
include 'include/function.php';

$user = getUser();

if (count($user) > 0) {

echo	"<div class='row'>"
."<div class='col-md-12'>"
."<table class='table table-bordered table-hover'>"
."<thead>"
."<tr>"
."<th class='col-md-4'>User ID</th>"
."<th class='col-md-4'>ID NUM</th>"
."<th class='col-md-4'>First Name</th>"
."<th class='col-md-4'>Last Name</th>"
."<th class='col-md-4'>Father Name</th>"
."<th class='col-md-2'>Status</th>"
."<th class='col-md-2'>Action</th>"
."</tr>"
."</thead>"
."<tbody>";

foreach ($user as $row) {

$finger 			= getUserFinger($row['user_id']);
$register			= '';
$added		= '';
$url_register		= base64_encode($base_path."register.php?user_id=".$row['user_id']);
if (count($finger) == 0) {

$register = "<a href='finspot:FingerspotReg;$url_register' onclick=\"user_register('".$row['user_id']."','".$row['id_num']."')\">
<img src='assets/image/finger-print.png' height='50px' width='50px' ></a>";

} else {

$added = '<span style="color:red">Added</span>';

}

echo					"<tr>"
."<td>".$row['user_id']."</td>"
."<td>".$row['id_num']."</td>"
."<td>".$row['first_name']."</td>"
."<td>".$row['last_name']."</td>"
."<td>".$row['father_name']."</td>"
."<td><code id='user_finger_".$row['user_id']."'>".count($finger)."</code></td>"
."<td>"
."$register"
."$added"
."</td>"
."</tr>";

}

echo
"</tbody>"
."</table>"
."</div>"
."</div>";

} else {

echo 'User Empty';

}
if(isset ($_GET['action']) && $_GET['action'] == 'checkreg') {

$sql1		= "SELECT count(finger_id) as ct FROM demo_finger WHERE user_id=".$_GET['user_id'];
$result1	= mysqli_query($mysql,$sql1);
$data1 		= mysqli_fetch_array($result1);

if (intval($data1['ct']) > intval($_GET['current'])) {
$res['result'] = true;			
$res['current'] = intval($data1['ct']);			
}
else
{
$res['result'] = false;
}
echo json_encode($res);

}
if(isset ($_GET['msg']) && $_GET['msg'] == 'success') {
?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>swal({
title: "Finger Print Successfully Added!",
icon: "Ok",
});</script>
<?php 
}
?>
</div>
</div>
</div>
</section>
<!--Section: Contact v.2-->
<script src="js/custom.js"></script>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>

