<?php
$base_path		= "http://localhost/ovsp/admin/";
$base_path1		= "http://localhost/ovsp/";
$db_name		= "ovsp";
$db_user		= "root";
$db_pass		= "";
$db_host		= "localhost";
$time_limit_reg = "15";
$time_limit_ver = "10";
$mysql = mysqli_connect($db_host, $db_user, $db_pass,$db_name);
if (!$mysql) 
{
echo mysqli_error();
}
?>