<?php
function getDevice() {
include "global.php";

$sql 	= 'SELECT * FROM demo_device ORDER BY device_name ASC';
$result	= mysqli_query($mysql,$sql);
$arr 	= array();
$i 	= 0;

while ($row = mysqli_fetch_array($result)) {

$arr[$i] = array(
'device_name'	=> $row['device_name'],
'sn'		=> $row['sn'],
'vc'		=> $row['vc'],
'ac'		=> $row['ac'],
'vkey'		=> $row['vkey']
);

$i++;

}

return $arr;

}

function getDeviceAcSn($vc) {
include "global.php";

$sql 	= "SELECT * FROM demo_device WHERE vc ='".$vc."'";
$result	= mysqli_query($mysql,$sql);
$arr 	= array();
$i 	= 0;

while ($row = mysqli_fetch_array($result)) {

$arr[$i] = array(
'device_name'	=> $row['device_name'],
'sn'		=> $row['sn'],
'vc'		=> $row['vc'],
'ac'		=> $row['ac'],
'vkey'		=> $row['vkey']
);

$i++;

}

return $arr;

}

function getDeviceBySn($sn) {
include "global.php";

$sql 	= "SELECT * FROM demo_device WHERE sn ='".$sn."'";
$result	= mysqli_query($mysql,$sql);
$arr 	= array();
$i 	= 0;

while ($row = mysqli_fetch_array($result)) {

$arr[$i] = array(
'device_name'	=> $row['device_name'],
'sn'		=> $row['sn'],
'vc'		=> $row['vc'],
'ac'		=> $row['ac'],
'vkey'		=> $row['vkey']
);

$i++;

}

return $arr;

}

function getUser() {
include "global.php";

$sql 	= 'SELECT * FROM userreg ORDER BY user_id ASC';
$result	= mysqli_query($mysql,$sql);
$arr 	= array();
$i 	= 0;

while ($row = mysqli_fetch_array($result)) {

$arr[$i] = array(
'user_id'	=> $row['user_id'],
'id_num'	=> $row['id_num'],
'first_name'	=> $row['first_name'],
'last_name'	=> $row['last_name'],
'father_name'	=> $row['father_name']
);

$i++;

}

return $arr;

}

function deviceCheckSn($sn) {
include "global.php";

$sql 	= "SELECT count(sn) as ct FROM demo_device WHERE sn = '".$sn."'";
$result	= mysqli_query($mysql,$sql);
$data 	= mysqli_fetch_array($result);

if ($data['ct'] != '0' && $data['ct'] != '') {
return "sn already exist!";
} else {
return 1;
}

}

function checkUserName($id_num) {
include "global.php";
$sql	= "SELECT id_num FROM userreg WHERE id_num = '".$id_num."'";
$result	= mysqli_query($mysql,$sql);
$row	= mysqli_num_rows($result);

if ($row>0) {
return "ID exist!";
} else {
return "1";
}

}

function getUserFinger($user_id) {
include "global.php";

$sql 	= "SELECT * FROM demo_finger WHERE user_id= '".$user_id."' ";
$result = mysqli_query($mysql,$sql);
$arr 	= array();
$i	= 0;

while($row = mysqli_fetch_array($result)) {

$arr[$i] = array(
'user_id'	=>$row['user_id'],
"finger_id"	=>$row['finger_id'],
"finger_data"	=>$row['finger_data']
);
$i++;

}

return $arr;

}

function getLog() {
include "global.php";

$sql 	= 'SELECT * FROM demo_log ORDER BY log_time DESC';
$result	= mysqli_query($mysql,$sql);
$arr 	= array();
$i 	= 0;

while ($row = mysqli_fetch_array($result)) {

$arr[$i] = array(
'log_time'		=> $row['log_time'],
'id_num'		=> $row['id_num'],
'data'			=> $row['data']
);

$i++;

}

return $arr;

}

function createLog($user_id) {
	session_start();
include "global.php";
$sql1 		= "SELECT * FROM userreg WHERE user_id='".$user_id."'";
	$result1 	= mysqli_query($mysql,$sql1);
	$userdata 		= mysqli_fetch_array($result1);
	      $_SESSION['userdata']=$userdata;
if ($userdata) {
return 1;				
} else {
return "Error insert log data!";
}

}

?>